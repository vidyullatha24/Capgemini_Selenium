package com.utilities;

public class DBConnectivity {

}
